import React, { useState } from "react";

const LeftComp = ({ ifos = [], onSelectCategory, onSelectItem }) => {
  const [text, setText] = useState("");
  const [selectedCategory, setSelectedCategory] = useState(null);
  const filteredCategories = ifos.filter((cat) =>
    cat.name.toLowerCase().includes(text.trim().toLowerCase()),
  );

  const filteredItems = selectedCategory
    ? (selectedCategory.items || []).filter((item) =>
        `${item.name} ${item.description || ""}`
          .toLowerCase()
          .includes(text.trim().toLowerCase()),
      )
    : [];
  const handleCategoryClick = (category) => {
    setSelectedCategory(category);
    setText("");
    onSelectCategory?.(category);
  };
  const handleBack = () => {
    setSelectedCategory(null);
    setText("");
  };
  const handleItemClick = (item) => {
    onSelectItem?.({
      ...item,
      category: selectedCategory.name,
    });
  };

  return (
    <div className="w-full space-y-5 p-3">
      <div className="flex items-center gap-3">
        <div className="relative flex-1">
          <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
            🔍
          </span>
          <input
            type="search"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={
              selectedCategory
                ? `Search ${selectedCategory.name} products...`
                : "Search categories..."
            }
            className="w-full rounded-xl border border-slate-200 bg-white py-3 pl-11 pr-4 text-slate-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-sky-400"
          />
          {text && (
            <button
              onClick={() => setText("")}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700"
            >
              ✕
            </button>
          )}
        </div>
      </div>
      {selectedCategory ? (
        <>
          <div className="flex items-center gap-3">
            <button
              onClick={handleBack}
              className="px-4 py-2 rounded-lg bg-slate-800 text-white hover:bg-slate-700"
            >
              ← Back
            </button>

            <div>
              <h2 className="text-xl font-bold text-slate-800">
                {selectedCategory.name}
              </h2>
              <p className="text-xs text-slate-400">
                {filteredItems.length} products found
              </p>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredItems.length > 0 ? (
              filteredItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleItemClick(item)}
                  className="group bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm hover:shadow-lg hover:border-sky-400 transition-all text-left active:scale-95"
                >
                  <div className="h-32 sm:h-36 bg-slate-100 overflow-hidden">
                    <img
                      src={item.image}
                      alt={item.name}
                      loading="lazy"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      onError={(e) => {
                        e.currentTarget.onerror = null;
                        e.currentTarget.src =
                          "https://placehold.co/400x300?text=Product";
                      }}
                    />
                  </div>

                  <div className="p-3">
                    <h3 className="font-bold text-slate-800 text-sm sm:text-base">
                      {item.name}
                    </h3>

                    <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                      {item.description}
                    </p>

                    <div className="flex justify-between items-center mt-3">
                      <span className="text-emerald-600 font-bold">
                        ₹{item.price}
                      </span>

                      <span className="text-xs bg-sky-50 text-sky-600 px-2 py-1 rounded-lg">
                        + Add
                      </span>
                    </div>
                  </div>
                </button>
              ))
            ) : (
              <div className="col-span-full text-center py-12">
                <p className="text-4xl mb-3">🔎</p>
                <p className="font-semibold text-slate-600">
                  No products found
                </p>
                <p className="text-sm text-slate-400">
                  Try another product name.
                </p>
              </div>
            )}
          </div>
        </>
      ) : (
        <>
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold text-slate-800">Categories</h2>

            <span className="text-sm text-slate-400">
              {filteredCategories.length} categories
            </span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {filteredCategories.length > 0 ? (
              filteredCategories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => handleCategoryClick(cat)}
                  className={`${cat.bgColor || "bg-indigo-500"} group rounded-2xl overflow-hidden flex flex-col items-center justify-center p-4 shadow-md hover:shadow-xl hover:scale-105 active:scale-95 transition-all`}
                >
                  <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full overflow-hidden border-4 border-white/40 shadow-md">
                    <img
                      src={cat.image}
                      alt={cat.name}
                      loading="lazy"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      onError={(e) => {
                        e.currentTarget.onerror = null;
                        e.currentTarget.src =
                          "https://placehold.co/400x300?text=Category";
                      }}
                    />
                  </div>

                  <span className="text-white font-bold text-sm sm:text-base text-center mt-3">
                    {cat.name}
                  </span>
                </button>
              ))
            ) : (
              <div className="col-span-full text-center py-12">
                <p className="text-4xl mb-3">🔎</p>
                <p className="font-semibold text-slate-600">
                  No categories found
                </p>
                <p className="text-sm text-slate-400">
                  Try a different search.
                </p>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default LeftComp;
